import React from 'react';
import Image from 'next/image';
import FadeInOnScroll from './FadeInOnScroll';

// A reusable component for each content block, now with delay
const ContentBlock = ({ visual, title, message, children, reverse = false, delay = 0 }) => (
  <FadeInOnScroll delay={delay}>
    <div className={`flex flex-col md:flex-row items-center gap-8 md:gap-12 ${reverse ? 'md:flex-row-reverse' : ''}`}>
      <div className="flex-1 w-full">
        <div className="relative aspect-[4/4] rounded-lg overflow-hidden shadow-lg">
          <Image src={visual} alt={title} fill className="object-cover" />
        </div>
      </div>
      <div className="flex-1">
        <h2 className="text-3xl font-serif font-bold mb-4">{title}</h2>
        <p className="text-lg text-muted-foreground mb-6">{message}</p>
        {children}
      </div>
    </div>
  </FadeInOnScroll>
);

const serviceContents = [
  {
    visual: "/images/wedding.png",
    title: "Together in Your Moment",
    message: "두 분이 예식에 집중하는 동안, 로비에서는 하객들의 따뜻한 축제가 펼쳐집니다.",
  },
  {
    visual: "/images/hero-wedding-01.png",
    title: "Perfect Quality",
    message: "신부님이 가장 예뻐 보이는 조명 값, 하객들이 소장하고 싶은 선명한 색감. 뷰포토는 사진의 본질에 집착합니다.",
    reverse: true,
    children: (
      <ul className="list-disc list-inside space-y-2 text-muted-foreground">
        <li>전문가용 DSLR 카메라</li>
        <li>스튜디오급 뷰티 조명 세팅</li>
        <li>두 분만의 커스텀 프레임 디자인</li>
      </ul>
    )
  },
  {
    visual: "/images/hero-wedding-02.png",
    title: "완벽한 현장 운영",
    message: "복잡한 로비 관리, 기기 조작 걱정 마세요. 전문 교육을 받은 2인의 스태프가 하객 한 분 한 분을 정중히 모십니다.",
  },
  {
    visual: "/images/promo-wedding.png",
    title: "세상에 하나뿐인 기록",
    message: "축의금 봉투에 담지 못한 하객들의 진심, 예식이 끝나면 가장 먼저 확인하실 수 있도록 정성껏 엮어 드립니다.",
    reverse: true,
  }
];

const WeddingServiceContent = () => {
  const animationDelay = 300; // ms

  return (
    <div className="space-y-20 md:space-y-28">
      
      {serviceContents.map((content, index) => (
        <ContentBlock
          key={content.title}
          {...content}
          delay={index * animationDelay}
        />
      ))}

      {/* 6. Trust: 투명한 패키지 & 예약 현황 */}
      <FadeInOnScroll delay={serviceContents.length * animationDelay}>
        <div className="text-center p-8 md:p-12 bg-muted rounded-lg">
          <h2 className="text-3xl font-bold mb-4">투명한 올인원 패키지</h2>
          <p className="text-lg text-muted-foreground mb-6">숨겨진 추가 비용은 없습니다. 오직 두 분의 예식에만 집중하는 150분.</p>
          <div className="inline-block bg-primary text-primary-foreground font-bold py-3 px-8 rounded-lg text-lg">
            실시간 예약 문의하기
          </div>
        </div>
      </FadeInOnScroll>

    </div>
  );
};

export default WeddingServiceContent;
