'use client';

import React, { useState, useEffect } from 'react';

export default function StaggeredTextReveal({ phrases, delayPerPhrase = 1500, className = "" }) {
  const [visiblePhrases, setVisiblePhrases] = useState([]);
  const [currentPhraseIndex, setCurrentPhraseIndex] = useState(0);

  useEffect(() => {
    if (currentPhraseIndex < phrases.length) {
      const timer = setTimeout(() => {
        setVisiblePhrases(prev => [...prev, phrases[currentPhraseIndex]]);
        setCurrentPhraseIndex(prev => prev + 1);
      }, delayPerPhrase);
      return () => clearTimeout(timer);
    }
  }, [phrases, currentPhraseIndex, delayPerPhrase]);

  return (
    <div className={`font-serif leading-tight tracking-wide font-light ${className}`}>
      {visiblePhrases.map((phrase, index) => (
        <React.Fragment key={index}>
          <span
            className="block opacity-0 animate-fadeInUp"
            style={{ animationDelay: `${index * 0.5}s`, marginBottom: index < visiblePhrases.length - 1 ? '10px' : '0' }}
          >
            {phrase}
          </span>
        </React.Fragment>
      ))}
    </div>
  );
}