'use client';

import React from 'react';
import './Handwriting.css';

const HandwritingText = ({ className = "" }) => {
  return (
    <div className={`w-full max-w-3xl text-center ${className}`}>
      <svg viewBox="0 0 1000 200">
        <defs>
          <mask id="text-mask">
            <rect className="mask-rect" x="0" y="0" width="0" height="200" fill="white" />
          </mask>
        </defs>
        
        <text x="50%" y="130" className="drawing-text" mask="url(#text-mask)">
          Vue Photobuth
        </text>
      </svg>
    </div>
  );
};

export default HandwritingText;