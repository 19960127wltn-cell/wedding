'use client';

import Link from 'next/link';
import { useState } from 'react';
import Image from 'next/image';
import { usePathname, useRouter } from 'next/navigation';

export default function GNB() {
  const [isOpen, setIsOpen] = useState(false); // For mobile menu
  const pathname = usePathname();
  const router = useRouter();

  const isWeddingPage = pathname === '/wedding';

  if (isWeddingPage) {
    return (
      <nav className="fixed w-full top-0 left-0 z-50 bg-background/80 backdrop-blur-sm shadow-sm py-3 px-6 md:px-12 flex justify-between items-center text-foreground h-14">
        {/* Back Button */}
        <div className="absolute left-6">
          <button onClick={() => router.back()} className="text-foreground focus:outline-none">
            <Image src="/icons/Icon _ arrow-left.svg" alt="Back" width={24} height={24} />
          </button>
        </div>
        {/* Title */}
        <div className="flex-grow text-center">
          <h1 className="text-xl font-semibold font-serif">Wedding</h1>
        </div>
        {/* Spacer to keep title centered */}
        <div className="w-6" /> 
      </nav>
    );
  }

  return (
    <nav className="fixed w-full top-0 left-0 z-50 bg-background/80 backdrop-blur-sm shadow-sm py-3 px-6 md:px-12 flex justify-between items-center text-foreground">
      {/* Logo/Brand Name */}
      <div className="flex items-center">
        <Link href="/" passHref className="relative w-24 h-8 md:w-32 md:h-10">
          <Image src="/images/logo.png" alt="VUE PHOTOBOOTH Logo" fill className="object-contain" />
        </Link>
      </div>

      {/* Desktop Navigation */}
      <div className="hidden md:flex space-x-8">
        <Link href="/" passHref className="text-lg font-serif hover:text-primary-hover transition-colors duration-300">
          Home
        </Link>
        <Link href="/wedding" passHref className="text-lg font-serif hover:text-primary-hover transition-colors duration-300">
          Wedding
        </Link>
        <Link href="/popup-event" passHref className="text-lg font-serif hover:text-primary-hover transition-colors duration-300">
          Popup/Event
        </Link>
        <Link href="/review" passHref className="text-lg font-serif hover:text-primary-hover transition-colors duration-300">
          Review
        </Link>
        <Link href="/contact" passHref className="text-lg font-serif hover:text-primary-hover transition-colors duration-300">
          Contact
        </Link>
      </div>

      {/* Mobile Menu Button */}
      <div className="md:hidden">
        <button onClick={() => setIsOpen(!isOpen)} className="text-foreground focus:outline-none">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            {isOpen ? (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            ) : (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
            )}
          </svg>
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-background/95 backdrop-blur-sm flex flex-col items-center py-4 space-y-4 shadow-lg">
          <Link href="/" passHref className="text-lg font-serif hover:text-primary-hover transition-colors duration-300" onClick={() => setIsOpen(false)}>
            Home
          </Link>
          <Link href="/wedding" passHref className="text-lg font-serif hover:text-primary-hover transition-colors duration-300" onClick={() => setIsOpen(false)}>
            Wedding
          </Link>
          <Link href="/popup-event" passHref className="text-lg font-serif hover:text-primary-hover transition-colors duration-300" onClick={() => setIsOpen(false)}>
            Popup/Event
          </Link>
          <Link href="/review" passHref className="text-lg font-serif hover:text-primary-hover transition-colors duration-300" onClick={() => setIsOpen(false)}>
            Review
          </Link>
          <Link href="/contact" passHref className="text-lg font-serif hover:text-primary-hover transition-colors duration-300" onClick={() => setIsOpen(false)}>
            Contact
          </Link>
        </div>
      )}
    </nav>
  );
}
