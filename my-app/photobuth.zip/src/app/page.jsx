'use client';

import Image from 'next/image';
import Link from 'next/link';
import { useState, useEffect } from 'react';
import FadeInOnScroll from '../components/FadeInOnScroll';
import StaggeredTextReveal from '../components/StaggeredTextReveal';
import ImageCarousel from '../components/ImageCarousel'; // Import ImageCarousel
import HandwritingText from '../components/HandwritingText'; // 1. Import new component

export default function MainPage() {
  const [showDimOverlay, setShowDimOverlay] = useState(false);
  const [showHandwritingText, setShowHandwritingText] = useState(false);
  // 2. Remove showMonologo state

  useEffect(() => {
    const dimTimer = setTimeout(() => {
      setShowDimOverlay(true);
    }, 1000);
    return () => clearTimeout(dimTimer);
  }, []);

  useEffect(() => {
    // StaggeredTextReveal has a total animation time. Let's start the handwriting after it.
    // Assuming StaggeredTextReveal takes about 2 seconds to be easily readable.
    const handwritingStartDelay = 2000;

    const timer = setTimeout(() => {
      setShowHandwritingText(true);
    }, handwritingStartDelay);
    return () => clearTimeout(timer);
  }, []);

  // 3. Remove useEffect for monologo

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      {/* Hero Section */}
      <section className="relative w-full h-[calc(100vh-3.5rem)] flex flex-col items-center justify-center text-center overflow-hidden pt-24 md:pt-32">
        {/* Background Image and Dimming */}
        <div className="absolute inset-0 z-0">
          <ImageCarousel
            images={[
              "/images/hero-wedding-02.png",
              "/images/hero-wedding-01.png",
              "/images/hero-wedding.png"
            ]}
          />
          {/* Dimming Overlay */}
          <div className={`absolute inset-0 bg-black z-10 transition-opacity duration-500 ${showDimOverlay ? 'opacity-40' : 'opacity-0'}`}></div>
        </div>

        {/* Main Content Area (Text) */}
        <FadeInOnScroll className="relative z-20 p-4 max-w-lg mx-auto flex flex-col items-center justify-center text-white">
          <StaggeredTextReveal
            phrases={["가장 소중한 날", "그날의 행복을 담아드려요"]}
            className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl mb-4"
            delayPerPhrase={500}
          />
          {/* 4. Render HandwritingText component */}
          {showHandwritingText && <HandwritingText className="mt-4" />}
        </FadeInOnScroll>
      </section>

      {/* "어떤 순간이든, 완벽하게" section */}
      <section className="pt-16 md:pt-24 pb-0 px-4 md:px-8 max-w-7xl mx-auto text-center">
        <FadeInOnScroll>
          <p className="font-serif text-2xl md:text-3xl lg:text-4xl text-foreground">
            모든 순간을, 완벽하게
          </p>
        </FadeInOnScroll>
      </section>

      {/* Promotional Blocks Section */}
      <section className="py-8 md:py-12 px-4 md:px-8">
        <div className="flex flex-col md:flex-row gap-4 md:gap-6">
          {/* Wedding Service Block */}
          <FadeInOnScroll className="flex-1 delay-200">
            <div className="relative bg-card shadow-xl rounded-lg overflow-hidden group">
              <Link href="/wedding" passHref>
                <div className="relative w-full h-80 md:h-96 overflow-hidden">
                  <img src="/images/promo-wedding.png" alt="Wedding Photo Booth Service" className="absolute top-0 left-0 w-full h-full object-cover"/>
                  <div className="absolute bottom-0 left-0 right-0 p-6 bg-white/75 text-zinc-800">
                    <h3 className="font-serif text-2xl mb-2">Wedding</h3>
                    <p className="font-sans text-base">일생의 한번 뿐인 소중한 순간을<br/>가장 아름답게 기록해보세요</p>
                  </div>
                </div>
              </Link>
            </div>
          </FadeInOnScroll>

          {/* Popup/Event Service Block */}
          <FadeInOnScroll className="flex-1 delay-500">
            <div className="relative bg-card shadow-xl rounded-lg overflow-hidden group">
              <Link href="/popup-event" passHref>
                <div className="relative w-full h-80 md:h-96 overflow-hidden">
                  <img src="/images/promo-event.png" alt="Popup and Event Photo Booth" className="absolute top-0 left-0 w-full h-full object-cover"/>
                  <div className="absolute bottom-0 left-0 right-0 p-6 bg-white/75 text-zinc-800">
                    <h3 className="font-serif text-2xl mb-2">POPUP</h3>
                    <p className="font-sans text-base">브랜드 런칭, 기업 행사 등<br/>모든 이벤트에 특별함을 더해드려요</p>
                  </div>
                </div>
              </Link>
            </div>
          </FadeInOnScroll>
        </div>
      </section>

      {/* Footer Section */}
      <footer className="py-8 md:py-12 bg-muted text-muted-foreground text-center">
        <p className="font-sans text-sm">FOOTER</p>
      </footer>
    </div>
  );
}