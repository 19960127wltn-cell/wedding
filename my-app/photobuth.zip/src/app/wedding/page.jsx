'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import WeddingServiceContent from '../../components/WeddingServiceContent';
import WeddingTemplateContent from '../../components/WeddingTemplateContent';
import StaggeredTextReveal from '../../components/StaggeredTextReveal';

export default function WeddingPage() {
  const [activeTab, setActiveTab] = useState('service');

  const tabs = [
    { id: 'service', label: 'Service' },
    { id: 'template', label: '템플릿' },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      {/* 1. Tab Area (Moved to top) */}
      <section className="bg-background shadow-md">
        <div className="max-w-7xl mx-auto flex justify-center">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`py-4 px-6 md:px-8 text-lg font-semibold transition-colors duration-300 ${
                activeTab === tab.id
                  ? 'border-b-2 border-primary text-primary'
                  : 'text-muted-foreground hover:text-primary'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </section>
      
      {/* 2. Banner Area (Modified for text animation) */}
      <section className="relative w-full bg-background py-12 md:py-16">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <StaggeredTextReveal
            phrases={[
              "깊게 남을 그날의 감동과,",
              "선명하게 기억될 하객의 미소,",
              "모든 순간을 소중히 담아드릴게요"
            ]}
            className="text-left text-2xl md:text-3xl lg:text-4xl text-foreground font-serif font-bold"
            delayPerPhrase={700}
          />
        </div>
      </section>

      {/* 3. Content Area */}
      <main className="max-w-7xl mx-auto w-full py-8 md:py-12 px-4 md:px-8">
        {activeTab === 'service' && <WeddingServiceContent />}
        {activeTab === 'template' && <WeddingTemplateContent />}
      </main>
    </div>
  );
}
