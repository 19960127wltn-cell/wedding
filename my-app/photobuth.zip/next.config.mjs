/** @type {import('next').NextConfig} */
const nextConfig = {
  // 필요한 설정이 있다면 여기에 작성 (없으면 비워두세요)
  reactStrictMode: true,
};

export default nextConfig;